# Lab Skill Basics for Thunderbird Taillight Lab
In this lab, we were introduced to the basics of flip-flop logic gates in sequential circuiting to demonstrate a thunderbird taillight.
Skills involved but not limited to:
  - Basic breadboard wiring
  - Use of logic gates
