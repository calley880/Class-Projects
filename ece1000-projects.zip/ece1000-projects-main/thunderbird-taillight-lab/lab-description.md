# Lab Description for Thunderbird Taillight
In this lab, we built a sequential circuit using flip-flop logic gates.

Lab inspiration: https://www.youtube.com/watch?v=0OS3XvpYkGU
