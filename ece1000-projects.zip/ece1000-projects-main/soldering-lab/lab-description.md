# Soldering Lab Description
We performed a small soldering lab involving a blinking LED circuit board to teach us the fundamentals of soldering. With this lab, there was no report involved.
