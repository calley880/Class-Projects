# Lab Skill Basics
Learned fundamentals of soldering as well as the safety procedures including but not limited to:
  - Metals used in soldering (antimony, bismuth, brass, copper, tin, silver, etc)
  - Interchangeable tips (conical, chisel, etc)
  - Sponges to clean oxidation that happens when soldering (brass and conventional sponges)
  - Safety glasses always worn during soldering
  - Soldering iron stands to assist in the process
