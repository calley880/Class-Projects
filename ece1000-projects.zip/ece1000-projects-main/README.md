# Name and Major
My name is Colby Alley and I am studying Electrical Engineering.
# Semester involved
This class was taken during my Spring 2025 semester.
# What is ECE 1000
ECE 1000 is the introductory level course involving my major, electrical engineering. 
It involves the introduction to follow-up courses involving digital systems, circuit analysis, and basic skills involving equipment used by electrical engineers.
# The purpose of this repository 
This repository outlines the projects involved in my first electrical engineering course.
Subfolders express the name of the project/lab with reports involving them.
This is held for record of my projects and labs that I feel were important to my new understanding of the electrical engineering industry. 

