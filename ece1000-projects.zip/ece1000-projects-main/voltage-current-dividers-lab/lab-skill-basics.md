# Learned skills involving the following but not limited to:
  - Using multimeters
  - Fundamentals of breadboard circuits and how they work
  - How to use LTSpice software for circuit simulation
  - Use power supplies
  - Understand fundamentals of potentiometers
