# Plant Watering System
This is my final project from my ECE 1000 course. The goals of this project is to measure the moisture level of the soil and to pump water if the Raspberry Pi Pico does not detect water.
# Main Components Involved
  - Raspberry Pi Pico
  - Soil Moisture Probe
  - Water Tank
  - Tubes
  - DC Motor Water Pump
