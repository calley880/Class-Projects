# Lab Skill Basics
Learned the basics of a function generator and oscilloscope as well as used a multi-meter to read values from capacitors 
involved in the lab.
